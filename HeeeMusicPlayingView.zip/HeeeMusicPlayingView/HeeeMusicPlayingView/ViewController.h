//
//  ViewController.h
//  HeeeMusicPlayingView
//
//  Created by diipo on 2017/6/26.
//  Copyright © 2017年 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

