//
//  ViewController.m
//  HeeeMusicPlayingView
//
//  Created by diipo on 2017/6/26.
//  Copyright © 2017年 Apple Inc. All rights reserved.
//

#import "ViewController.h"
#import "HeeeMusicAnimateView.h"

@interface ViewController ()
@property (nonatomic,strong) HeeeMusicAnimateView *musicAnimateView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _musicAnimateView = [HeeeMusicAnimateView new];
    _musicAnimateView.viewColor = [UIColor grayColor];
    _musicAnimateView.totalWidth = 50;
    _musicAnimateView.center = CGPointMake(100, 100);
    [self.view addSubview:_musicAnimateView];
    [_musicAnimateView start];
    
    UIButton *stopOrStartBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 100, 40)];
    stopOrStartBtn.center = CGPointMake([UIScreen mainScreen].bounds.size.width - 100, 100);
    stopOrStartBtn.backgroundColor = [UIColor cyanColor];
    [stopOrStartBtn setTitle:@"开始/暂停" forState:UIControlStateNormal];
    [stopOrStartBtn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [stopOrStartBtn addTarget:self action:@selector(stopOrStart) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:stopOrStartBtn];
}

- (void)stopOrStart {
    if (_musicAnimateView.isAnimate) {
        [_musicAnimateView stop];
    }else{
        [_musicAnimateView start];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
